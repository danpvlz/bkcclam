<?php

namespace App\Models\Associated;

use Illuminate\Database\Eloquent\Model;

class Sector extends Model
{
    protected $table = 'Sector'; 
    protected $primaryKey = 'idSector';
}

<?php

namespace App\Models\FormacionYDesarrollo;

use Illuminate\Database\Eloquent\Model;

class Curso extends Model
{
    protected $table = 'Curso'; 
    protected $primaryKey = 'idCurso'; 
}

<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class ReservaConcepto extends Model
{
    protected $table = 'ReservaConcepto'; 
    protected $primaryKey = 'idReserva';
}

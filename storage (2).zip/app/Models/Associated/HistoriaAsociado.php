<?php

namespace App\Models\Associated;

use Illuminate\Database\Eloquent\Model;

class HistoriaAsociado extends Model
{
    protected $table = 'HistoriaAsociado'; 
    protected $primaryKey = 'idHistoriaAsociado';
}

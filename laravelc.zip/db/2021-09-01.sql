ALTER TABLE `Cuenta` ADD `fechaVencimiento` DATE NULL AFTER `fechaEmision`;

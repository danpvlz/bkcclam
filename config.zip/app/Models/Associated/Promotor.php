<?php

namespace App\Models\Associated;

use Illuminate\Database\Eloquent\Model;

class Promotor extends Model
{
    protected $table = 'Promotor'; 
    protected $primaryKey = 'idPromotor';
    public $timestamps = false;
}

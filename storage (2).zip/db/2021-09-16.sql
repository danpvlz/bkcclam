INSERT INTO `Membresia` (`idMembresia`, `year`, `mes`, `masdeuno`, `estado`, `cobrado`, `pagado`, `idAsociado`, `idCuenta`, `idSector`, `user_create`, `user_update`, `created_at`, `updated_at`) VALUES 
(NULL, '2021', '1', '', '2', '93.5', '93.5', '308', '14484', '2', '0', '1', '2021-04-07 21:04:51', '2021-04-12 11:31:08');
INSERT INTO `Membresia` (`idMembresia`, `year`, `mes`, `masdeuno`, `estado`, `cobrado`, `pagado`, `idAsociado`, `idCuenta`, `idSector`, `user_create`, `user_update`, `created_at`, `updated_at`) VALUES 
(NULL, '2021', '2', '', '2', '93.5', '93.5', '308', '14484', '2', '0', '1', '2021-04-07 21:04:51', '2021-04-12 11:31:08');
INSERT INTO `Membresia` (`idMembresia`, `year`, `mes`, `masdeuno`, `estado`, `cobrado`, `pagado`, `idAsociado`, `idCuenta`, `idSector`, `user_create`, `user_update`, `created_at`, `updated_at`) VALUES 
(NULL, '2021', '3', '', '2', '93.5', '93.5', '308', '14484', '2', '0', '1', '2021-04-07 21:04:51', '2021-04-12 11:31:08');
INSERT INTO `Membresia` (`idMembresia`, `year`, `mes`, `masdeuno`, `estado`, `cobrado`, `pagado`, `idAsociado`, `idCuenta`, `idSector`, `user_create`, `user_update`, `created_at`, `updated_at`) VALUES 
(NULL, '2021', '4', '', '2', '93.5', '93.5', '308', '14484', '2', '0', '1', '2021-04-07 21:04:51', '2021-04-12 11:31:08');
INSERT INTO `Membresia` (`idMembresia`, `year`, `mes`, `masdeuno`, `estado`, `cobrado`, `pagado`, `idAsociado`, `idCuenta`, `idSector`, `user_create`, `user_update`, `created_at`, `updated_at`) VALUES 
(NULL, '2021', '5', '', '2', '93.5', '93.5', '308', '14484', '2', '0', '1', '2021-04-07 21:04:51', '2021-04-12 11:31:08');
INSERT INTO `Membresia` (`idMembresia`, `year`, `mes`, `masdeuno`, `estado`, `cobrado`, `pagado`, `idAsociado`, `idCuenta`, `idSector`, `user_create`, `user_update`, `created_at`, `updated_at`) VALUES 
(NULL, '2021', '6', '', '2', '93.5', '93.5', '308', '14484', '2', '0', '1', '2021-04-07 21:04:51', '2021-04-12 11:31:08');
INSERT INTO `Membresia` (`idMembresia`, `year`, `mes`, `masdeuno`, `estado`, `cobrado`, `pagado`, `idAsociado`, `idCuenta`, `idSector`, `user_create`, `user_update`, `created_at`, `updated_at`) VALUES 
(NULL, '2021', '7', '', '2', '93.5', '93.5', '308', '14484', '2', '0', '1', '2021-04-07 21:04:51', '2021-04-12 11:31:08');
INSERT INTO `Membresia` (`idMembresia`, `year`, `mes`, `masdeuno`, `estado`, `cobrado`, `pagado`, `idAsociado`, `idCuenta`, `idSector`, `user_create`, `user_update`, `created_at`, `updated_at`) VALUES 
(NULL, '2021', '8', '', '2', '93.5', '93.5', '308', '14484', '2', '0', '1', '2021-04-07 21:04:51', '2021-04-12 11:31:08');
INSERT INTO `Membresia` (`idMembresia`, `year`, `mes`, `masdeuno`, `estado`, `cobrado`, `pagado`, `idAsociado`, `idCuenta`, `idSector`, `user_create`, `user_update`, `created_at`, `updated_at`) VALUES 
(NULL, '2021', '9', '', '2', '93.5', '93.5', '308', '14484', '2', '0', '1', '2021-04-07 21:04:51', '2021-04-12 11:31:08');
INSERT INTO `Membresia` (`idMembresia`, `year`, `mes`, `masdeuno`, `estado`, `cobrado`, `pagado`, `idAsociado`, `idCuenta`, `idSector`, `user_create`, `user_update`, `created_at`, `updated_at`) VALUES 
(NULL, '2021', '10', '', '2', '93.5', '93.5', '308', '14484', '2', '0', '1', '2021-04-07 21:04:51', '2021-04-12 11:31:08');
INSERT INTO `Membresia` (`idMembresia`, `year`, `mes`, `masdeuno`, `estado`, `cobrado`, `pagado`, `idAsociado`, `idCuenta`, `idSector`, `user_create`, `user_update`, `created_at`, `updated_at`) VALUES 
(NULL, '2021', '11', '', '2', '93.5', '93.5', '308', '14484', '2', '0', '1', '2021-04-07 21:04:51', '2021-04-12 11:31:08');
INSERT INTO `Membresia` (`idMembresia`, `year`, `mes`, `masdeuno`, `estado`, `cobrado`, `pagado`, `idAsociado`, `idCuenta`, `idSector`, `user_create`, `user_update`, `created_at`, `updated_at`) VALUES 
(NULL, '2021', '12', '', '2', '93.5', '93.5', '308', '14484', '2', '0', '1', '2021-04-07 21:04:51', '2021-04-12 11:31:08');

delete FROM `Membresia` where idMembresia=14844;
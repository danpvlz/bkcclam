<?php

namespace App\Models\Associated;

use Illuminate\Database\Eloquent\Model;

class Associated extends Model
{
    protected $table = 'Asociado'; 
    protected $primaryKey = 'idAsociado';
}

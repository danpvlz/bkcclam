<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class FolderContenido extends Model
{
    protected $table = 'FolderContenido'; 
    protected $primaryKey = 'idFolderContenido';
    public $timestamps = false;
}

<?php

namespace App\Models\Associated;

use Illuminate\Database\Eloquent\Model;

class ComiteGremial extends Model
{
    protected $table = 'ComiteGremial'; 
    protected $primaryKey = 'idComite';
}

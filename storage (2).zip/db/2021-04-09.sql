ALTER TABLE `Persona` ADD `actividadSecundaria` VARCHAR(200) NULL AFTER `actividad`;
ALTER TABLE `Empresa` ADD `actividadSecundaria` VARCHAR(200) NULL AFTER `actividad`;

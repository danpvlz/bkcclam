<?php

namespace App\Models\FormacionYDesarrollo;

use Illuminate\Database\Eloquent\Model;

class Participante extends Model
{
    protected $table = 'Participante'; 
    protected $primaryKey = 'idParticipante';
}

<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class CuentaDetalle extends Model
{
    protected $table = 'CuentaDetalle'; 
    protected $primaryKey = 'idCuentaDetalle';
}

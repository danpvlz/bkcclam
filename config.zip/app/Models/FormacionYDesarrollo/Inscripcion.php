<?php

namespace App\Models\FormacionYDesarrollo;

use Illuminate\Database\Eloquent\Model;

class Inscripcion extends Model
{
    protected $table = 'Inscripcion'; 
    protected $primaryKey = 'idInscripcion';
}

<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class Asistencia extends Model
{
    protected $table = 'Asistencia'; 
    protected $primaryKey = 'idAsistencia';
    public $timestamps = false;
}

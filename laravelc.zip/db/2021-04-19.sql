ALTER TABLE `CuentaDetalle` ADD `descuento` FLOAT NOT NULL DEFAULT '0' AFTER `subtotal`;

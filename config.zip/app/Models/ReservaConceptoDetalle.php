<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class ReservaConceptoDetalle extends Model
{
    protected $table = 'ReservaConceptoDetalle'; 
    protected $primaryKey = 'idReservaDetalle';
    public $timestamps = false;
}

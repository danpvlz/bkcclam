<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class KPIPass extends Model
{
    protected $table = 'KPIPass'; 
    protected $primaryKey = 'idPass';
    public $timestamps = false;
}

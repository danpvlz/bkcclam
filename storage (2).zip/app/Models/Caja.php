<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class Caja extends Model
{
    protected $table = 'Cuenta'; 
    protected $primaryKey = 'idCuenta';
}
